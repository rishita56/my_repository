# Go to https://replit.com/@appbrewery/rock-paper-scissors-start?v=1
import random
rock = "🪨"
paper = "🧻"
scissors = "✂️"
game_list = [rock, paper, scissors]
user_choice = int(input("type 0 for rock, 1 for paper,2 for scissors: "))
print(game_list[user_choice])
computer_choice = random.randint(0, 2)
print("computer chose: ")
print(game_list[computer_choice])

if user_choice >= 3 or user_choice < 0: 
  print("You typed an invalid number, you lose!") 
elif user_choice == 0 and computer_choice == 2:
  print("You win!")
elif computer_choice == 0 and user_choice == 2:
  print("You lose")
elif computer_choice > user_choice:
  print("You lose")
elif user_choice > computer_choice:
  print("You win!")






print(f"computer chose: {computer_choice}")

